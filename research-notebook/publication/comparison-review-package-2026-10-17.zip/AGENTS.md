# Writing guidance

Mike requests that writing here and in later work follow ASD-STE100 at about 80%.
Use this as a strong style preference, not a measured compliance score.

- Use short sentences, active voice, and familiar words.
- Use one term for each technical concept. Define necessary technical terms.
- Give each paragraph one main topic. Put the main point first.
- Give instructions in a clear sequence. State conditions before their actions.
- Preserve mathematical meaning, assumptions, units, notation, and source claims.
- Keep exact theorem statements and quotations when a rewrite would change them.
- Avoid word substitutions that make the text less natural or less precise.
- Do not claim full STE compliance without checking the full standard and dictionary.

Source: https://www.asd-ste100.org/about_STE.html
The official overview describes writing rules, a controlled dictionary, and permitted
technical nouns and verbs. The full standard has not been checked for this project.

Keep reports concise and candid. Separate proved results, numerical evidence, and
open questions. Do not give invented confidence percentages or publication odds.
