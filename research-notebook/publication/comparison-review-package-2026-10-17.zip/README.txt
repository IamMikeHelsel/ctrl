Brake, Switch, Stay Safe: comparison revision,17October2026.
Start with publication/recovery-manuscript/main.pdf and research/adjacent-controls/direct-comparison/README.txt.
The original recovery proof is unchanged. The direct interval comparison is Python-trusted and not a Lean safety proof.
DirectSwitch is a separately kernel-checked release-state example. Its verifier is verify_switch.py.
The full package retains the pinned base sources; external Lean/mathlib dependencies must be installed as described in BASE-README.txt.
No publication, hardware validation, or control superiority is claimed.
