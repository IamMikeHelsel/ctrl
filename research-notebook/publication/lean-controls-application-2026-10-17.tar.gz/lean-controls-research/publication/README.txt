LEAN-CHECKED TRAVEL SAFETY — working paper and artifact, 17 October 2026

START HERE
  manuscript/main.pdf          seven-page focused working paper
  manuscript/main.tex          editable LaTeX source
  ../lean-controls/README.txt  main proof reproduction instructions
  application-fresh-replay.txt independent fresh project-source check
  application-paper-review.txt separate AI-agent manuscript review
  application-comparison/     same four travel witnesses replayed with Lean SOS

The main application is a sampled acceleration actuator with known first-order
lag, magnitude saturation, positive-minimum timing jitter, and held errors. In
normalized coordinates, every initial state in the specified ellipsoid E<=12
stays within |x(t)|<=2 for all real t>=0, when h<=1/5 and the combined pre-clamp
request-error plus post-clamp disturbance magnitude is at most1/100. The initial
state (0,0,1) lies inside and genuinely clips. The actual execution is continuous
and satisfies the plant ODE inside each open sampling interval.

MeasuredTravel proves the actual perturbed controller theorem and a separate
ideal nearest-grid sensor corollary. PhysicalTravel proves the physical-unit
transformation, actual scaled ODE and envelope |X(T)|<=2 U tau^2. Illustrative
values tau=.1s,U=2m/s^2 give a4cm envelope with maximum20ms sample interval.
No machine has been calibrated. Initial position alone does not suffice:
TravelScope contains a checked escape counterexample outside the ellipsoid.

EVIDENCE
The main workflow passed all four steps: build/axiom audit, producer regression
checks, saturated-model mutation checks, and regeneration/checking of10benchmark
certificates. See ../lean-controls/evidence/project-verification.json.
A separate frozen-source replay copied83files, rebuilt43project modules and the
aggregate, and audited516named public declarations in52.61seconds. Only standard
axioms propext/Classical.choice/Quot.sound occur. The replay reused the pinned
Lean toolchain and isolated dependency cache; it did not rebuild all dependencies.
All copied and original source hashes stayed unchanged. Counts include helpers,
not original research claims.

A matched SOS replay checks the same four polynomial vertex residuals after an
exact translation into48weighted squares. It is shared-witness interoperability,
not independent search, a second complete application proof, or a performance win.

READING ORDER
  manuscript/main.pdf
  ../lean-controls/LeanControls/TravelSafety.lean
  ../lean-controls/LeanControls/MeasuredTravel.lean
  ../lean-controls/LeanControls/PhysicalTravel.lean
  ../lean-controls/LeanControls/TravelScope.lean
Then follow imports for exact plant/enclosure/sector/certificate/error/clock layers.

REBUILD
Use the pinned Lean project commands in ../lean-controls/README.txt. From this
publication directory, a normal TeX installation can compile manuscript/main.tex
with manuscript as the working directory. Tectonic0.17.0 was used for the exported
PDF; manuscript-compilation.json records source, figure and output hashes.
For the separate upstream SOS replay, see application-comparison/REPRODUCE.txt.

PUBLICATION BOUNDARY
This is a focused formalization case study, not a new general control method,
hardware acceptance, award eligibility determination, submission, or public release.
AI-agent reviews are useful checks but not human refereeing. Before submission:
obtain human domain review; establish a meaningful reuse/comparison result; settle
full author details, affiliation, contributions and a release license. The existing
source archive omits toolchains, caches and third-party repositories. No license
has been selected for these new project sources.

Earlier draft reviews,29/40-module replay checkpoints and the research/travel
archives are retained as history. Current evidence is application-fresh-replay
and the main project's source-bound verification manifest.

Prize-problem and controls-award screening is a separate track under
../research/prize-problems/. Historical reward amounts are not confirmed payouts.

The packaged prize appendix contains curated metadata, source URLs/hashes and
our screening notes. Downloaded third-party papers and website captures are
omitted. build_catalog.py rebuilds its offline browser from erdos-manifest.json.
This appendix is a research-selection aid, separate from the Lean proof evidence.
