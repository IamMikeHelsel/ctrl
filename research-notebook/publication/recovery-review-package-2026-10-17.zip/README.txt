RECOVERY AND HANDOFF RESEARCH REVIEW PACKAGE

Start with publication/recovery-manuscript/main.pdf (five pages) or
research/adjacent-controls/index.html (video, proof links and comparison).

Proof setup and replay: research/adjacent-controls/recovery-proof/README.txt
Animation: research/adjacent-controls/recovery-animation/recovery-proof.mp4
Pretty-print tools: research/academic-tools/pretty-math.html

The old complete base project is included under lean-controls/. Its original
README is BASE-README.txt. The new extension is seven modules /98 audited
theorems with fresh source and kernel replay. Pinned toolchain/dependencies
must be provisioned; cached binaries and Docker layers are not shipped.

All content is local research, not submitted or deployed. Human review,
licensing and publication suitability remain pending. No hardware guarantee.
The direct-feedback numerical comparison does not show recovery superiority.

artifact-sha256.json hashes every included file except itself.
