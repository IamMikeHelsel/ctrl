ROBUST SAMPLED-AXIS REVIEW PACKAGE — LOCAL DRAFT, 17 October 2026

Read publication/robust-manuscript/main.pdf. The six-page paper includes its
exact model/assumptions, theorem, proof architecture, ablations and limits.
Machine-readable descriptive contract: publication/robust-benchmark/model.json.
It is metadata, not an executable semantics parser.

Proof reproduction
1. Install elan/Lean using https://lean-lang.org/install/ and Python 3.10+.
2. Enter lean-controls/. Keep lean-toolchain and lake-manifest.json unchanged.
3. Obtain pinned dependencies: lake exe cache get
4. Create a Python environment and install requirements.txt (SymPy 1.14.0).
5. Using that Python, run scripts/verify_project.py.
   This includes build/axiom audit, producer and model-mutation tests, ten
   benchmark regenerations, and twelve uncertainty certificate regenerations
   with two negative model tests. All five steps are expected to pass.
   Deliberately mutated Lean sources are expected to be rejected within tests.
Use ./check.sh for only aggregate build and axiom audit.

The included evidence reports successful local runs. It does not remove the
need to execute those commands on the reviewer's machine. Toolchains/mathlib
cache are not bundled. Initial provisioning may be large. A full fresh-source
replay reuses pinned Lean and dependency caches and does not bootstrap them.
The complete archive manifest lists hashes for every included file.

This focused package contains the current paper and proof evidence, not the
full workspace's historical papers, Erdős or prize-research files. Earlier
proof modules remain in the audited project and are labelled as separate
scopes in the project README. No source license has yet been selected; this
local review archive is not a public software release. No affiliation or
institutional endorsement is implied. Human review and attribution are pending.
