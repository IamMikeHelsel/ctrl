WORKING PUBLICATION PACKAGE — 17 October 2026

Start with manuscript/main.tex, which opens in Codex's built-in LaTeX editor and
PDF preview. The companion Lean project is ../lean-controls. Its README.txt gives
commands and assurance boundaries. The manuscript is a draft, not a submission.

The research result worth evaluating is the complete chain:

  rational polynomial transition and positive energy form
  -> untrusted Bernstein/LDL producer
  -> exact Lean reconstruction and positivity proofs
  -> explicit held-input ODE model bridges
  -> arbitrary sampling jitter and within-segment nominal bounds
  -> elapsed-time-scaled disturbance composition
  -> all-real-time travel safety with genuine clipping.

The selected application is a normalized actuator-lag axis with command limit
one. For every initial state in z^T P z <= 12, every positive-minimum sampling
sequence with h <= 1/5, and every sequence of held post-clamp command disturbances
|w| <= 1/100, TravelSafety proves |x(t)| <= 2 for all t >= 0. The ellipsoid
constrains position, velocity, and acceleration jointly. Its admitted initial
state (0,0,1) requests -2 and applies -1. TravelExecution proves full-state
continuity and the plant ODE inside each sampling interval.

None of the individual ingredients is claimed as a new control theorem. Existing
SOS, matrix positivity, Lean control, and hybrid-system work overlaps substantially.
The related-work comparison identifies what must be distinguished and evaluated.

Main claims and locations

1. Every h in an interval, not a numerical grid:
   BernsteinCertificate.interval_psd, covered_psd, step_decrease.
2. Energy has checked positive lower/upper state bounds:
   Generated.<case>.lower_pos, upper_pos, certified_energy_bounds.
3. Every permitted sampling sequence:
   Generated.<case>.certified_jitter.
4. The matrices describe the written held plants:
   HeldModels.Jerk/Planar.segment_eq_transition and DoubleIntegratorBridge.
5. Bounds throughout each nominal segment:
   HeldModels.Jerk/Planar.sampled_segment_bound and DoubleIntegratorBridge.
   SamplingClock additionally assembles the nominal two-state trajectory and
   proves its energy envelope for every nonnegative real time.
6. Generic local disturbance induction and ultimate bound at samples:
   Certificate.local_affine_guarantee, quadratic_trajectory.
7. The conservative full budget rules out active clipping:
   SaturationBoundary.budget_forces_clipping_inactive.
8. A genuinely clipped finite recovery and robust infinite tail:
   SaturatedEntry.recovery_guarantee.
9. Exact exponential actuator lag, with a checked polynomial enclosure:
   ActuatorLag.segment_ode, segment_enclosed, segment_energy_decrease;
   VertexCertificate.shared_bound transfers the common polynomial-vertex bound.
10. Regional travel safety with actual clipping and positive disturbance budget:
   TravelSafety.travel_limit, state_invariant, active_initial_travel;
   TravelExecution.state_continuousOn_nonnegative, state_ode_interior.
   The actual exponential solution, four common-energy vertices, exact response
   bound and timing coverage are all linked by checked theorems.
11. Matrix-problem groundwork, no open-problem resolution:
   OrthogonalLyapunov and CoupledLyapunov; RankFourCore proves a conditional two-block comparison. The remaining
   coordinate-existence obligations are not a completed rank-four theorem.

Review history and resolution

manuscript-review.txt and math-review.txt record review snapshots. Their reported
missing double-integrator bridge has since been added. The manuscript now states
the sign assumptions for U and distinguishes sample-time robust bounds from
nominal within-segment bounds. It also includes the active-clipping example and
the counterexample to pairwise monotone intersample energy. The old reviews are
preserved rather than rewritten to imply they reviewed later changes.

Evidence of checking is distinct from review. Final build/audit manifests and
logs are under lean-controls/evidence. Compiler success alone without statement
inspection would not catch an unintended model or an overstated interpretation.

Practical next decisions

  1. Map the normalized travel certificate to an actual axis and obtain defensible
     parameter/uncertainty ranges. No physical units or calibration are assumed.
  2. Extend the matched-object comparison to the saturated travel application.
     Compare the same P, region, disturbance channel, intervals, and guarantee.
     The baseline Bernstein-to-SOS shared-witness replay is already complete.
  3. Seek a knowledgeable human review of assumptions and distinct contribution.
  4. Finalize authorship, affiliation, contribution statement, license, and venue
     only after the contribution is clear. No upload or submission has occurred.

The first-session lean-research-report.html elsewhere in the workspace is a
historical report. This package and the latest verification evidence supersede its
theorem counts and completion status.

Final verification checkpoint

The travel checkpoint contains 40 modules and 464 named public declarations.
Use lean-controls/evidence/project-verification.json and travel-fresh-replay.json
for current source-bound results. The earlier 29-module/307-declaration checkpoint
and its source archive remain intact under final-fresh-replay and
lean-controls-research-2026-10-17.tar.gz. The new source package is
lean-controls-travel-2026-10-17.tar.gz. Cached pinned dependencies and the existing
Lean toolchain are disclosed in each replay. Counts include helper facts.

The same-object SOS experiment has now been executed. VerifiedSOSReplay.lean
passes the pinned SOS checker with the standard axiom closure; its eight-square
witness is translated from the existing Bernstein certificate. The two failed
automated searches are retained as negative evidence in explicitly UNVERIFIED
files. They are not part of the main Lean project or its accepted theorem audit.
See comparison/sos-run.txt for versions, commands, all outcomes, and fair-use
limits on timing comparisons. The MatrixSOS adapter remains unverified.

The source archive is local and has not been uploaded. It contains source, pinned
dependency manifests, reviews, and verification evidence, with no toolchains,
compiler outputs, dependency caches, or cloned third-party repositories.

The travel-specific semantic review is travel-safety-review.txt; the preceding
design and prior-art review is ../research/travel-limit/design-review.txt.
